<?php

header('Location: ../');

?>
