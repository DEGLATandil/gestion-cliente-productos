<?php
	session_start();
	header('Content-Type: text/html; charset=UTF-8');
	#inicia la conexion con la base
	include("../db/api_db.php");
	include("../common/controlador.php");
	$db_manager = new DB();
	$controlador = new CONTROLADOR();
	$controlador->check_session();
	

	if(!empty($_POST['add_all'])){
		$w_cuit = 'cuit="'.$db_manager->clear_string($_POST['cuit']).'"';
		$total_cli = $db_manager->total('cliente',$w_cuit);
		if($total_cli == 0){ 	
			$db_manager->add_cliente($db_manager->clear_string($_POST['nombre']),$db_manager->clear_string($_POST['cuit']),$db_manager->clear_string($_POST['email']),$db_manager->clear_string($_POST['iva']),$db_manager->clear_string($_POST['domicilio']),$db_manager->clear_string($_POST['telefono']),$db_manager->clear_string($_POST['comentario']));
			$controlador->set_msg(true,'El cliente '.$db_manager->clear_string($_POST['nombre']).' fue agregado exitosamente');
			$controlador->set_session_expire();
			$db_manager->close_conexion();
			header('Location: ../cli/'); 
		}else{
			$controlador->set_error(true,'Existe un cliente con el CUIT ingresado.');
			$controlador->set_session_expire();
			$db_manager->close_conexion();
			header('Location: add.php'); 	
		}
	}else{
		if(!empty($_POST['editar'])){
			$where = 'id_cliente='.$controlador->desencriptar($_POST['v']);
			$element = 'nombre = "'.$db_manager->clear_string($_POST['nombre']).'", cuit="'.$db_manager->clear_string($_POST['cuit']).'", email="'.$db_manager->clear_string($_POST['email']).'", iva="'.$db_manager->clear_string($_POST['iva']).'"';
			$element .= ', domicilio="'.$db_manager->clear_string($_POST['domicilio']).'", telefono="'.$db_manager->clear_string($_POST['telefono']).'", comentario="'.$db_manager->clear_string($_POST['comentario']).'"'; 
			$db_manager->update_one_element('cliente',$element,$where);
			$controlador->set_msg(true,'El cliente '.$db_manager->clear_string($_POST['nombre']).' fue editado exitosamente');
			$controlador->set_session_expire();
			$db_manager->close_conexion();
			header('Location: det.php?v='.$_POST['v']);
		}else{	
			#Else final si no cumple nada
			$db_manager->close_conexion();
			header('Location: ../exit.php');
		}
	}
	
?> 

