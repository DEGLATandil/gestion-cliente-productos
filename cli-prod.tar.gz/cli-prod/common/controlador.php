<?php
  class CONTROLADOR
  {
    function __construct()
    {
      //session_start();
    }

    function set_info_login($id,$user)
    {
		$_SESSION["user"][0] = $id; 
		$_SESSION["user"][1] = $user;
    }
    
    
    function set_login()
    {
		$_SESSION["admin"] = "LOGGED";	
	}

    function get_cant_registros()
    {
		$registros = 20;
		return $registros;
    }


    function is_logged()
    {
		if($_SESSION["admin"] == "LOGGED")
		{
			return true;
		}else{
			return false;
		}
    }
 
    function get_pagina($pagina) 
    {
		if (!isset($pagina))
		{
			return 1;
		}
		else
		{
			return $pagina;
		} 
    }

    function get_inicio($pagina,$registros) 
    {
		if ($pagina == 1)
		{
			return 0;
		}
		else
		{
			return ($pagina-1) * $registros;
		} 
    }

    function encriptar($valor)
    {
		return base64_encode($valor);
    }

    function desencriptar($valor)
    {
		return base64_decode($valor);
    }

    function set_error($valor,$texto)
    {
		$_SESSION['error'][0] = $valor;
		$_SESSION['error'][1] = $texto;
	}
	
	function hay_error()
	{
		if (isset($_SESSION['error'][0])){
			return $_SESSION['error'][0];
		}else{
			return false;	
		}
	}
	
	function get_error()
	{
		return $_SESSION['error'][1];
	}
	
	function set_msg($valor,$texto)
    {
		$_SESSION['msg'][0] = $valor;
		$_SESSION['msg'][1] = $texto;
	}
	
	function hay_msg()
	{
		if (isset($_SESSION['msg'][0])){
			return $_SESSION['msg'][0];
		}else{
			return false;
		}	
	}
	
	function get_msg()
	{
		return $_SESSION['msg'][1];
	}
	
    function get_id()
	{
		return base64_decode($_SESSION["user"][0]);
    }
    
    function get_my_email()
	{
		return $_SESSION["user"][1];
    }
    
    function set_session_expire()
    {
		$_SESSION['expire'] = time() + (10800);
	}
    
    function check_session()
    {
		$now = time();
		if($now > $_SESSION['expire'])
		{
			session_unset();
			header('Location: ../logout.php');
		}
	}	
	
	function get_si_no($valor)
	{
		switch ($valor) {
			case 0:
				return 'No';
				break;
			case 1:
				return 'Si';
				break;
		}
	}
	
	function get_hoy()
	{
		$hoy = getdate();
      	if($hoy['mday'] < 10){
			$dia='0'.$hoy['mday'];
      	}else{
			$dia=$hoy['mday'];
      	}	
		if($hoy['mon'] < 10){
			$mes='0'.$hoy['mon'];
		}else{
			$mes=$hoy['mon'];
		}	
		$hoy = $hoy['year'].'/'.$mes.'/'.$dia;
		return $hoy;
	}
	
	function get_anio()
	{
		$hoy = getdate();
      	return $hoy['year'];
	}
	
	function get_anio_anterior()
	{
		$hoy = getdate();
      	return ($hoy['year']-1);
	}
	
	function truncate_valor($valor,$cant)
	{
		if(strlen($valor) > $cant)
		{
			return substr($valor, 0, $cant)."...";
		}else{
			return $valor;
		}											
	}
	
	function truncate_pass($valor,$cant)
	{
		if(strlen($valor) > $cant)
		{
			return substr($valor, 0, $cant);
		}else{
			return $valor;
		}											
	}
	
	function truncate_number($valor,$cant)
	{
		return round($valor,$cant);						
	}
	
	function replace_desc($valor)
	{
		$order   = array("\r\n", "\n", "\r");
		return str_replace($order, "<br/>", $valor); 
	}
	
	function dividir_termino($condicion, $valor) 
	{
		return explode($condicion, $valor);
	}
	
	#Retorna la fecha con formato dd/mm/aaaa
	function get_fecha($valor)
	{
		$fecha_v = explode('-', $valor);
		return $fecha_v[2].'/'.$fecha_v[1].'/'.$fecha_v[0];
	}
	
	function get_fecha_new($valor)
	{
		$fecha_v = explode('/', $valor);
		return $fecha_v[2].'/'.$fecha_v[1].'/'.$fecha_v[0];
	}
	
	function convertir_a_fecha($valor)
	{
		$d = new DateTime($valor);

		$timestamp = $d->getTimestamp(); 
		return $formatted_date = $d->format('Y-m-d'); 
	}
	
	
	function replace_valor($valor,$secuencia,$texto)
	{
		return str_replace($valor, $secuencia, $texto);
	} 
	
	function capitalizar($valor)
	{
		$capitalizada=ucwords(strtolower($valor));
		$capitalizada = str_replace("Á", "á", $capitalizada);
		$capitalizada = str_replace("É", "é", $capitalizada);
		$capitalizada = str_replace("Í", "í", $capitalizada);
		$capitalizada = str_replace("Ó", "ó", $capitalizada);
		$capitalizada = str_replace("Ú", "ú", $capitalizada);
		$capitalizada = str_replace("Ñ", "ñ", $capitalizada);
		$capitalizada = str_replace("Ü", "Ü", $capitalizada);
		return $capitalizada;
	}
	
	function esperar($valor)
	{
		// dormir durante x segundos
		sleep($valor);	
	}
	
	function encontrar_cadena($cadena,$valor)
	{
		return strpos($cadena, $valor);
	}
	
	function get_cantidad($valor)
	{
		return count($valor);	
	}
	
  } // class CONTROLADOR
?>
