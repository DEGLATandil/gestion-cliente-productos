<?php
  session_start();	
  include("../db/api_db.php");
  include("controlador.php");
  $db_manager = new DB();
  $controlador = new CONTROLADOR();
  if(!empty($_POST['login'])){
	$user = $db_manager->clear_string($_POST['user']);
	$pass = $db_manager->clear_string($controlador->encriptar($controlador->truncate_pass($_POST['password'],100)));
	$where='usuario="'.$user.'" AND password="'.$pass.'" AND logueable=1';
	$table='personal_ld';
	$total_login = $db_manager->total($table,$where);
	if($total_login == 1){
		$controlador->set_login();
		$controlador->set_session_expire();
		$user_info = $db_manager->select_one_element($table,$where);
		$controlador->set_info_login($controlador->encriptar($user_info['id_personal']),$user_info['usuario']);
		$controlador->set_error(false,"");
		$controlador->set_msg(false,"");
		$db_manager->close_conexion();
		header('Location: ../main');
	}else{
		$db_manager->close_conexion();
		$controlador->set_error(true,"Usuario ó Contraseña inválido, vuelva a intentarlo. Consulte si tiene permiso para acceder al sistema.");
		header('Location: ../logout.php');
	  }
  }else{
	  if(isset($_GET['l'])){
		$db_manager->close_conexion();
		session_unset();
		header('Location: ../logout.php');
	  }
  }
  
   		
?>
