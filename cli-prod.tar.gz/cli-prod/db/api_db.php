<?php
  class DB
  {
    var $iden;

    function __construct()
    {
		#$_SESSION["db"][4] = mysqli_connect("localhost", "deglacom_root", "francesca09","deglacom_messages");
		#$_SESSION["db"][4] = mysqli_connect("localhost", "root", "root","lomadistribuidora");
		#$_SESSION["db"][4] = mysqli_connect("sql112.eshost.com.ar", "eshos_19017870", "fran2009","eshos_19017870_ld");
		$_SESSION["db"][4] = mysqli_connect("localhost", "root", "root","ld");
		#$_SESSION["db"][4] = mysqli_connect("sql112.eshost.com.ar", "eshos_19017870", "fran2009","eshos_19017870_ld");
		$_SESSION["db"][4]->set_charset("utf8");
    }

    ################################################################################
    ################################################################################
    function clear_string($element)
    {	 	
        return $_SESSION["db"][4]->escape_string($element);
    }	

    function info_table($element)
    {	 	
        return $element->fetch_assoc();
    }	
    
    function select_one_element($table,$where)
    {
      $sentencia = "SELECT * FROM $table WHERE $where LIMIT 1";
      $resultado = $_SESSION["db"][4]->query($sentencia);
      if(!$resultado) 
       #die("Error: no se pudo realizar la consulta one". " ");
       echo '<script language="javascript">window.location="../exit.php"</script>;';
      return $resultado->fetch_assoc();
    }
    
    function select_order_list($table,$where,$order,$inicio,$registros)
    {
     // Sentencia SQL: muestra todo el contenido de la tabla "producto" 
      $sentencia = "SELECT * FROM $table WHERE $where ORDER BY $order LIMIT ".$inicio." , ".$registros.""; 
      // Ejecuta la sentencia SQL 
      $resultado = $_SESSION["db"][4]->query($sentencia);
      if(!$resultado) 
       #die("Error: no se pudo realizar la consulta orden". " ");
       echo '<script language="javascript">window.location="../exit.php"</script>;';
      return $resultado; 
    }
    
    function select_list($table,$where)
    {
      $sentencia = "SELECT * FROM $table WHERE $where"; 
      // Ejecuta la sentencia SQL 
      $resultado = $_SESSION["db"][4]->query($sentencia);
      if(!$resultado) 
       #die("Error: no se pudo realizar la consulta". " ");
       echo '<script language="javascript">window.location="../exit.php"</script>;';
      return $resultado; 
    }
    
    function select_distinct($distinct,$table,$where)
    {
      $sentencia = "SELECT DISTINCT($distinct) FROM $table WHERE $where"; 
      // Ejecuta la sentencia SQL 
      $resultado = $_SESSION["db"][4]->query($sentencia);
      if(!$resultado) 
       #die("Error: no se pudo realizar la consulta". " ");
       echo '<script language="javascript">window.location="../exit.php"</script>;';
      return $resultado; 
    }    
    
    function total($table,$where)
    {
	  $sentencia = "SELECT * FROM $table WHERE $where";
	  $resultado = $_SESSION["db"][4]->query($sentencia);
	  	if(!$resultado) 
       		#die("Error: no se pudo realizar la consulta total". " ");
       		echo '<script language="javascript">window.location="../exit.php"</script>;';
      	return $resultado->num_rows;
    }
    ##############################################################################################################################	
    
    function update_one_element($table,$element,$where)
    {
      $sentencia = "UPDATE $table SET $element WHERE $where LIMIT 1;"; 
      // Ejecuta la sentencia SQL 
      $resultado = $_SESSION["db"][4]->query($sentencia);
      if(!$resultado) 
       #die("Error: no se pudo realizar la actualizacion". " ");
       echo '<script language="javascript">window.location="../exit.php"</script>;';
    }
    
    ##############################################################################################################################
    function add_producto($articulo,$scanner,$precio,$iva,$codbar,$categoria)
	{
		$sentencia = "INSERT INTO producto(categoria,scanner,articulo,iva,precio,codbar) VALUES 
	   ('$categoria','$scanner','$articulo','$iva','$precio','$codbar');";
      // Ejecuta la sentencia SQL 
      $resultado = $_SESSION["db"][4]->query($sentencia);
      if(!$resultado) 
       #die("Error: no se pudo realizar la acción". " ");
       echo '<script language="javascript">window.location="../exit.php"</script>;';
	}
	
	function add_cliente($nombre,$cuit,$email,$iva,$domicilio,$telefono,$comentario)
	{
		$sentencia = "INSERT INTO cliente(codigo,nombre,cuit,email,domicilio,iva,telefono,comentario) 
		VALUES (0,'$nombre','$cuit','$email','$domicilio','$iva','$telefono','$comentario');";
      // Ejecuta la sentencia SQL 
      $resultado = $_SESSION["db"][4]->query($sentencia);
      if(!$resultado) 
       #die("Error: no se pudo realizar la acción". " ");
       echo '<script language="javascript">window.location="../exit.php"</script>;';
	}
    
    ##############################################################################################################################
    
    function add_newsletter($mail,$fecha)
    {
      $sentencia = "INSERT INTO newsletter(mail,fecha) VALUES ('$mail','$fecha');";
      // Ejecuta la sentencia SQL 
      $resultado = $_SESSION["db"][4]->query($sentencia);
      if(!$resultado) 
       #die("Error: no se pudo realizar la actualizacion". " ");
       echo '<script language="javascript">window.location="../exit.php"</script>;';
    }
    
    function free_elements($element)
    {	 	
        return $element->free();
    }

    function close_conexion()					
    {
		$_SESSION["db"][4]->close();
    }	

  
  } // class DB
?>
