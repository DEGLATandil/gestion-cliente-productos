SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `ld`
-- Es necesario crear la base de datos con el nombre ld
--

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS producto (
	id_producto integer(20) NOT NULL AUTO_INCREMENT,
	categoria varchar(100) NOT NULL,
	scanner varchar(100) NOT NULL,
	articulo varchar(200) NOT NULL,
	marca varchar(100) DEFAULT NULL,
	iva varchar(50) DEFAULT NULL,
	precio varchar(50) DEFAULT NULL,
	codbar varchar(100) DEFAULT NULL,
	borrado BOOLEAN DEFAULT FALSE,
	PRIMARY KEY (id_producto)
 )ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
 
INSERT INTO `producto` (`id_producto`, `categoria`, `scanner`, `articulo`, `marca`, `iva`, `precio`, `codbar`, `borrado`) VALUES
(1, 'Abrazaderas', '6221', 'ABRAZADERA PERFECTO 100-120 FLEJE 12mm', NULL, '21,00', '20,75', NULL, 0);
 
 
CREATE TABLE `cliente` (
  `id_cliente` int(20) NOT NULL AUTO_INCREMENT,
  `codigo` int(20) NOT NULL,
  `nombre` varchar(200) COLLATE latin1_spanish_ci DEFAULT NULL,
  `cuit` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `pass` varchar(200) COLLATE latin1_spanish_ci DEFAULT 'TERjbGllbnRlIQ==',
  `email` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `domicilio` varchar(200) COLLATE latin1_spanish_ci DEFAULT NULL,
  `iva` varchar(200) COLLATE latin1_spanish_ci DEFAULT NULL,
  `telefono` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `comentario` varchar(400),
   PRIMARY KEY (id_cliente)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`id_cliente`, `codigo`, `nombre`, `cuit`, `pass`, `email`, `domicilio`, `iva`, `telefono`, `activo`, `comentario`) VALUES
(1, 24, 'USER TEST', '20246444109', 'TERjbGllbnRlIQ==', '', '', 'Responsable Inscripto', '', 1, NULL);


---
--- ACA VAN LOS QUE PUEDEN ENTRAR AL SISTEMA
--- Clave = LDadmin
---
CREATE TABLE personal_ld (
  id_personal integer(11) NOT NULL AUTO_INCREMENT,
  nombre varchar(100) NOT NULL,
  apellido varchar(100) NOT NULL,
  email varchar(100) NOT NULL,
  usuario varchar(100) NOT NULL,
  password varchar(100) DEFAULT "TERhZG1pbg==",
  logueable boolean default true,
  PRIMARY KEY (id_personal)
)ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO personal_ld(nombre,apellido,email,usuario,password) VALUES ("admin","admin","admin@admin.com","admin","TERhZG1pbg==");

