<?php
  
  if(isset($_GET['l'])){
	header('Location: common/login.php?l=true');
  }
?>
