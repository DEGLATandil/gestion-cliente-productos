<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum- scale=1, user-scalable=0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CLI - PROD</title>

    <!-- Bootstrap Core CSS -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="assets/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="assets/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    <script type="text/javascript">
		function deshabilitaRetroceso(){
			window.location.hash="no-back-button";
			window.location.hash="Again-No-back-button" //chrome
			window.onhashchange=function(){window.location.hash="no-back-button";}
		}	
    </script>

</head>

<body  style="background: url('assets/img/body-bg.gif');" onload="deshabilitaRetroceso()">

    <div class="container">
        <div class="row">
			<div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">CLI - PROD</h3>
                    </div>
                    <div class="panel-body">
                        <form action="../common/login.php" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input id="user"  class="form-control" placeholder="Usuario" name="user" type="text" autofocus required>
                                </div>
                                <div class="form-group">
                                    <input id="password" class="form-control" placeholder="Contraseña" name="password" type="password" value="" required>
                                </div>
                                <button class="btn btn-lg btn-success btn-block" id="login" name="login" value="login">Ingresar</button>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
