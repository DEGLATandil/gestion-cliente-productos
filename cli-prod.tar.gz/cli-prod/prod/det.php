﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum- scale=1, user-scalable=0">
    <title>Sistema de gestión Loma Distribuidora</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   
   <script type="text/javascript">
	  function check_cat(){
		if (document.getElementById('cat').checked == true) {
			document.getElementById('categoria_new').style.display='block';
			document.getElementById('categoria').style.display='none';
			document.getElementById('cat').value=1;
		} else {
			document.getElementById('categoria_new').style.display='none';
			document.getElementById('categoria').style.display='block';
			document.getElementById('cat').value=0;
		}
	  }	
	  	
	</script>
   
</head>
<?php
	session_start();	
	include("../db/api_db.php");
	include("../common/controlador.php");
	$db_manager = new DB();
	$controlador = new CONTROLADOR();
	$controlador->check_session();
	if(!$controlador->is_logged())
	{
		echo '<script language="javascript">window.location="../exit.php"</script>;'; 
	}
	$where = 'id_producto='.$controlador->desencriptar($_GET['v']);
	$producto = $db_manager->select_one_element('producto',$where);
	
	$categorias = $db_manager->select_distinct('categoria','producto','1=1 ORDER BY categoria');
	
?>
<body>
     
           
          
    <div id="wrapper">
         <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="adjust-nav">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                    
                </div>
              
                <span class="logout-spn" >
                 
                </span>
            </div>
        </div>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li class="active-link">
                        <a href="../main" ><i class="fa fa-bars"></i>Menú</a>
                        <a href="search.php" ><i class="fa fa-arrow-left"></i>Volver</a>
                        <a href="../exit.php?l=true" ><i class="glyphicon glyphicon-off"></i>Salir</a>
                    </li>
                 </ul>
			</div>
		</nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
					
                    <div class="col-lg-12">
                     <h2>DETALLES DEL PRODUCTO</h2>
                     <!-- Mensajes -->
					<?php
						if($controlador->hay_error())
						{
							echo'<div class="alert alert-danger" role="alert" >
									<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
										'.$controlador->get_error().'
								</div>';
							$controlador->set_error(false,'');	
						}
						if($controlador->hay_msg())
						{
							echo'<div class="alert alert-success" role="alert" >
									<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
										'.$controlador->get_msg().'
								</div>';
							$controlador->set_msg(false,'');	
						}
					?>
					<!-- Mensajes --> 
                    </div>
                </div>              
                 <!-- /. ROW  -->
                <hr />
                <!-- /. ROW  --> 
                <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
						<div id="filtro" class="panel-body">
							<form action="action.php" name="add" method="post">
								<div class="col-xs-12 col-sm-5 placeholder">
									<label>Producto</label>
									<?php echo'<input type="text" id="v" name="v" class="form-control"  value="'.$_GET['v'].'" style="display:none;">';?>
									<?php echo'<input type="text" id="articulo" name="articulo" class="form-control"  value="'.$producto['articulo'].'" placeholder="Producto" required>';?>
								</div>
								<div class="col-xs-12 col-sm-3 placeholder">
									<label>Código</label>
									<?php echo'<input type="text" id="scanner" name="scanner" class="form-control"  value="'.$producto['scanner'].'" placeholder="Código" required>';?>
								</div>
								<div class="col-xs-12 col-sm-4 placeholder">
									<label>Precio $</label>
									<?php echo'<input type="text" id="precio" name="precio" class="form-control"  value="'.$producto['precio'].'" placeholder="Precio" required>';?>
								</div>
								
								<div class="col-xs-12 col-sm-4 placeholder">
									<label>Categoría</label>
									<select id="categoria" name="categoria" class="form-control" title="Seleccionar Categoría">
									 <?php 
										while($row = $db_manager->info_table($categorias)) {
											if($producto['categoria'] == $row['categoria']){
												echo '<option value="'.$row['categoria'].'" selected>'.$row['categoria'].'</option>';
											}else{
												echo '<option value="'.$row['categoria'].'">'.$row['categoria'].'</option>';
											}
										}	
									  ?>
									</select>
									
									<?php echo'<input type="text" id="categoria_new" name="categoria_new" class="form-control"  value="" placeholder="Categoría" style="display:none;">';?>
								</div>
								<div class="col-xs-12 col-sm-1 placeholder">
									<br>
									<?php echo'<div class="checkbox">
													<label>
														<input type="checkbox" id="cat" name="cat" value="0" title="Nueva Categoría" onclick="check_cat();"> Nueva
													</label>
												</div>';?>
								</div>	
								<div class="col-xs-12 col-sm-3 placeholder">
									<label>IVA %</label>
									<?php echo'<input type="text" id="iva" name="iva" class="form-control"  value="'.$producto['iva'].'" placeholder="IVA">';?>
								</div>
								<div class="col-xs-12 col-sm-4 placeholder">
									<label>Cód. Barra</label>
									<?php echo'<input type="text" id="codbar" name="codbar" class="form-control"  value="'.$producto['codbar'].'" placeholder="Cód. Barra">';?>
								</div>
								<div class="col-xs-12 col-sm-12 placeholder">
									<br>
									<center><button type="submit" class="btn btn-success" id="editar" name="editar" value="editar" >Editar</button></center>
								</div>
							</form>
						 </div>
					</div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
           
					
           </div>
                  
				   
			</div>
             <!-- /. PAGE INNER  -->
         </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
		<div class="footer">
			<div class="row">
				<div class="col-lg-12" >
                    &copy;  Loma Distribuidora | Design by: <a href="http://binarytheme.com" style="color:#fff;" target="_blank">www.binarytheme.com</a> | Implement by: <a href="https://degla.com.ar" style="color:#fff;" target="_blank">DEGLA Consultora</a>
                </div>
            </div>
        </div>
        
        
        
          

     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
    
    
   
</body>
</html>
