﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum- scale=1, user-scalable=0">
    <title>Sistema de gestión Loma Distribuidora</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   
   <script type="text/javascript">
		function salir(){
			document.location = "../exit.php?l=true";
			
		}
	</script>	
</head>
<?php
	session_start();	
	include("../common/controlador.php");
	$controlador = new CONTROLADOR();
	$controlador->check_session();
	if(!$controlador->is_logged())
	{
		echo '<script language="javascript">window.location="../exit.php"</script>;'; 
	}
?>
<body>
     
           
          
    <div id="wrapper">
         <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="adjust-nav">
                <div class="navbar-header">
                    
                    
                    
                </div>
              
                <span class="logout-spn" >
				  <i class="glyphicon glyphicon-home" onclick="location.href='../main'"></i>
                  <i class="glyphicon glyphicon-off" onclick="salir()"></i>
                </span>
            </div>
        </div>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li class="active-link">
                        <a href="../main" ><i class="fa fa-bars"></i>Menú</a>
                    </li>
                 </ul>
			</div>

        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-lg-12">
                     <h2>GESTIÓN DE PRODUCTOS</h2>
                     <!-- Mensajes -->
					<?php
						if($controlador->hay_error())
						{
							echo'<div class="alert alert-danger" role="alert" >
									<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
										'.$controlador->get_error().'
								</div>';
							$controlador->set_error(false,'');	
						}
						if($controlador->hay_msg())
						{
							echo'<div class="alert alert-success" role="alert" >
									<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
										'.$controlador->get_msg().'
								</div>';
							$controlador->set_msg(false,'');	
						}
					?>
					<!-- Mensajes -->    
                    </div>
                </div>              
                 <!-- /. ROW  -->
                <hr />
                 <!-- /. ROW  --> 
                 <div class="row text-center pad-top">
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="div-square">
							<a href="add.php" >
							<i class="fa fa-file fa-5x"></i>
							<h4>Nuevo Producto</h4>
							</a>
						</div>
					</div> 
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="div-square">
							<a href="search.php" >
							<i class="fa fa-clipboard fa-5x"></i>
							<h4>Buscar Producto</h4>
							</a>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="div-square">
							<a href="delete.php" >
							<i class="fa fa-ban fa-5x"></i>
							<h4>Productos Borrados</h4>
							</a>
						</div>
					</div>
					
					
              </div>
                  
				   
			</div>
             <!-- /. PAGE INNER  -->
         </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
		<div class="footer">
			<div class="row">
				<div class="col-lg-12" >
                    &copy;  Loma Distribuidora | Design by: <a href="http://binarytheme.com" style="color:#fff;" target="_blank">www.binarytheme.com</a> | Implement by: <a href="https://degla.com.ar" style="color:#fff;" target="_blank">DEGLA Consultora</a>
                </div>
            </div>
        </div>
          

     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
    
   
</body>
</html>
