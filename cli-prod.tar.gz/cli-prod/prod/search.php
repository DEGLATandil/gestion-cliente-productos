﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum- scale=1, user-scalable=0">
    <title>Sistema de gestión Loma Distribuidora</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="../assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   
   <script type="text/javascript">
		function filtrar(){
			var name=document.getElementById("name_dis").value;
			var ape=document.getElementById("apellido").value;
			var sStr1 = "?fil=true&cli="+name+"&cuit="+ape;
			window.location.href = sStr1;
	   }	

	   function remove_filtro(){
			var sStr1 = "search.php";
			window.location.href = sStr1;
	   }
	   
	   function remove(num){
			var valor = document.getElementById(num+"_delete").value;
			document.getElementById("text_modal").value = valor;
		}
		
		function delete_element(){
			var valor = document.getElementById("text_modal").value;
			document.location = valor;
		}
	</script>	
</head>
<?php
	session_start();	
	include("../db/api_db.php");
	include("../common/controlador.php");
	$db_manager = new DB();
	$controlador = new CONTROLADOR();
	$controlador->check_session();
	if(!$controlador->is_logged())
	{
		echo '<script language="javascript">window.location="../exit.php"</script>;'; 
	}
	
	#Elimino
	if(isset($_GET['del']))
	{	
		$where_eliminado='(id_producto='.$controlador->desencriptar($_GET ['f']).') AND (borrado=0)';
		$cant = $db_manager->total('producto',$where_eliminado);
		if ($cant > 0)
		{
			$elemento='borrado=1';
			$where_eliminado='(id_producto='.$controlador->desencriptar($_GET ['f']).')';
			$db_manager->update_one_element('producto',$elemento,$where_eliminado);
			$controlador->set_msg(true,'El producto fue eliminado exitosamente');
		}
	}
	
	$registros = $controlador->get_cant_registros();
	$where='(borrado=0)';
	if (isset($_GET['pagina'])){
		$pagina = $controlador->get_pagina($_GET ['pagina']);
	}else{
		$pagina = 1;
	}
	$inicio = $controlador->get_inicio($pagina,$registros);
	$name="";
	$apellido="";
	if (isset($_GET['fil']))
	{	
		if(strcmp($_GET['cli'], '') !== 0){
			$where.=" AND ";
			$name= $db_manager->clear_string($_GET['cli']);
			$where.=" (articulo LIKE '%".$name."%')";
		}
		if(strcmp($_GET['cuit'], '') !== 0){
			$where.=" AND ";
			$apellido= $db_manager->clear_string($_GET['cuit']);
			$where.=" (scanner LIKE '%".$apellido."%')";
		}
		
	}
	
	
	$elemetos = $db_manager->select_order_list('producto',$where,'articulo',$inicio,$registros);
	$total = $db_manager->total('producto',$where);
	$total_paginas = ceil($total / $registros);
?>
<body>
     
           
          
    <div id="wrapper">
         <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="adjust-nav">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                    
                </div>
              
                <span class="logout-spn" >
                 
                </span>
            </div>
        </div>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li class="active-link">
                        <a href="../main" ><i class="fa fa-bars"></i>Menú</a>
                        <a href="../prod" ><i class="fa fa-arrow-left"></i>Volver</a>
                        <a href="../exit.php?l=true" ><i class="glyphicon glyphicon-off"></i>Salir</a>
                    </li>
                 </ul>
			</div>
		</nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
					
                    <div class="col-lg-12">
                     <h2>BUSCAR PRODUCTOS</h2>
                     <!-- Mensajes -->
					<?php
						if($controlador->hay_error())
						{
							echo'<div class="alert alert-danger" role="alert" >
									<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
										'.$controlador->get_error().'
								</div>';
							$controlador->set_error(false,'');	
						}
						if($controlador->hay_msg())
						{
							echo'<div class="alert alert-success" role="alert" >
									<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
										'.$controlador->get_msg().'
								</div>';
							$controlador->set_msg(false,'');	
						}
					?>
					<!-- Mensajes --> 
                    </div>
                </div>              
                 <!-- /. ROW  -->
                <hr />
                <!-- /. ROW  --> 
                <div class="row">
                <div class="col-lg-12">
                    <h5><font color="#4B8A08">Filtro</font></h5>
					<div class="panel panel-default">
						<div class="col-xs-6 col-sm-3 placeholder" style="width:95%; float:left;">
						</div>
						<div class="col-xs-6 col-sm-3 placeholder" style="width:5%; float:left;">
						<a id="o_filtro" href="javascript:;" onclick="ocultar_filtro(true);" title="Ocultar filtro"><span class="glyphicon glyphicon-menu-up" aria-hidden="true"></span></a>
						<a id="v_filtro" href="javascript:;" onclick="ocultar_filtro(false);" title="Mostrar filtro" style="display:none;"><span class="glyphicon glyphicon-menu-down" aria-hidden="true"></span></a>
						</div>
						<div id="filtro_ocul" class="panel-body" style="display:none;">
					
						</div>
						<div id="filtro" class="panel-body">
							<div class="col-xs-12 col-sm-5 placeholder">
									<?php echo'<input type="text" id="name_dis" name="name_dis" class="form-control"  value="'.$name.'" placeholder="Producto">';?>
							</div>
							<div class="col-xs-12 col-sm-5 placeholder">
									<?php echo'<input type="text" id="apellido" name="apellido" class="form-control"  value="'.$apellido.'" placeholder="Código">';?>
							</div>
							<div class="col-xs-12 col-sm-2 placeholder">
									<?php
									echo'<a id="filter" href="javascript:;" onclick="filtrar();" title="Aplicar filtro"><span class="glyphicon glyphicon-search" aria-hidden="true" ></span></a>'; 
									echo'<a id="filter" href="javascript:;" onclick="remove_filtro();" title="Aplicar filtro"><span class="glyphicon glyphicon-remove" aria-hidden="true" ></span></a>'; 
								?>
							</div>
						 </div>
					</div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div id="dispo_table" class="row">
				<div class="col-lg-12">
					<div class="col-lg-12 col-md-12">
                        <h5><font color="#4B8A08">Lista de Productos</font></h5>
                        <div class="panel-group" id="accordion">
							<?php
								$vacio=true;
								$num=0;
								while($row = $db_manager->info_table($elemetos)) {
									$vacio=false;
									$idref='#'.$num;
									echo'<div class="panel panel-default">
										 <div class="panel-heading">
											<h4 class="panel-title">
												<a data-toggle="collapse" data-parent="#accordion" href="'.$idref.'" class="collapsed"><b>'.$row['scanner'].'</b> - '.$row['articulo'].'</a>
											</h4>
										</div>
										<div id="'.$num.'" class="panel-collapse collapse" style="height: 0px;">
											<div class="panel-body">
												<b>Categoría: </b>'.$row['categoria'].' <b>Precio: </b> $'.$row['precio'].' <a id="'.$row['id_producto'].'_delete" href="javascript:;" onclick="remove('.$num.');" data-toggle="modal" data-target="#myModal" ><font color="red">ELIMINAR </font></a> | <a href="det.php?v='.$controlador->encriptar($row['id_producto']).'" >DETALLE</a>
												<input type="text" id="'.$num.'_delete" value="?del=true&f='.$controlador->encriptar($row['id_producto']).'" style="display:none;">
											</div>
										</div>
									</div>';
									$num+=1;	
								}
								if($vacio){
									echo '<div class="alert alert-warning">
										<p><strong>No hay productos para mostrar.</strong></p>
									</div>';
								}
							?>	
                            
                        </div>
                    </div>
                    <!-- Pagination -->
                    <hr />
					<nav aria-label="...">
						<ul class="pager">
						<?php 
							if($total>$registros){
								if($pagina > 1){
									echo '<li class="previous"><a href="?fil=true&cli='.$name.'&cuit='.$apellido.'&pagina='.($pagina-1).'" title="Ir a la página anterior"><span aria-hidden="true">&larr;</span> Anterior</a></li>';
									if($pagina < $total_paginas){
										echo'<li class="next"><a href="?fil=true&cli='.$name.'&cuit='.$apellido.'&pagina='.($pagina+1).'" title="Ir a la siguiente página">Siguiente <span aria-hidden="true">&rarr;</span></a></li>';	
									}
								}else{
									echo'<li class="next"><a href="?fil=true&cli='.$name.'&cuit='.$apellido.'&pagina='.($pagina+1).'" title="Ir a la siguiente página">Siguiente <span aria-hidden="true">&rarr;</span></a></li>';
								}	
							}
							?>		
						</ul>
					</nav>	
                    <!-- Pagination -->

                        
                    </div>
				</div>	
                <!-- /.row --> 
					
              </div>
                  
				   
			</div>
             <!-- /. PAGE INNER  -->
         </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
		<div class="footer">
			<div class="row">
				<div class="col-lg-12" >
                    &copy;  Loma Distribuidora | Design by: <a href="http://binarytheme.com" style="color:#fff;" target="_blank">www.binarytheme.com</a> | Implement by: <a href="https://degla.com.ar" style="color:#fff;" target="_blank">DEGLA Consultora</a>
                </div>
            </div>
        </div>
        
        
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4 class="modal-title" id="myModalLabel">Confirmar Eliminación</h4>
                    </div>
                    <div class="modal-body">
						<div id="text_consul">¿Realmente desea eliminar el producto seleccionado?</div>
						<?php
							echo'<input type="text" id="text_modal" value="" style="display:none;">';
						?>
                    </div>
                    <div id="add_rol_div_del" class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                        <button type="button" id="add_rol_button" class="btn btn-primary" onclick="delete_element();">Aceptar</button>
                    </div>
                 </div>
             </div>
        </div>
          

     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="../assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="../assets/js/bootstrap.min.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="../assets/js/custom.js"></script>
    
    
   
</body>
</html>
